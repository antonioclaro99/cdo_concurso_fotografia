import gspread
from google.oauth2.service_account import Credentials
import pandas as pd

# ==== CONFIGURACIÓN ====

SERVICE_ACCOUNT_FILE = "credentials.json"

SHEET_VOTOS = "FormularioVotante"              # hoja donde llegan las respuestas del formulario
SHEET_USUARIOS = "UsuariosConCodigo"         # hoja con email + codigo válidos
SHEET_FOTOS = "Fotos"                        # hoja con id_foto (Drive) + numero_foto
SHEET_RANKING = "Ranking"                    # hoja donde guardaremos el resultado final
SHEET_REGISTRO = "LoginConcursoFotografia"
SHEET_FORMULARIO_FOTOGRAFO = "FormularioFotografo"

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

# ==== FUNCIONES ====

def get_sheets_client():
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return gspread.authorize(creds)

def sheet_to_df(sheet):
    data = sheet.get_all_records()
    return pd.DataFrame(data)

def main():
    client = get_sheets_client()

    # === 1️⃣ Leer todas las hojas necesarias ===
    df_votos = sheet_to_df(client.open(SHEET_VOTOS).sheet1)
    df_usuarios = sheet_to_df(client.open(SHEET_USUARIOS).sheet1)
    df_fotos = sheet_to_df(client.open(SHEET_FOTOS).sheet1)
    df_registro = sheet_to_df(client.open(SHEET_REGISTRO).sheet1)
    df_formulario_fotografo = sheet_to_df(client.open(SHEET_FORMULARIO_FOTOGRAFO).sheet1)


    # 🆕 Leer fotógrafos para luego obtener nombres
    df_fotografos = sheet_to_df(client.open("FormularioFotografo").sheet1)
    if "Correo electrónico" in df_fotografos.columns:
        df_fotografos["Correo electrónico"] = df_fotografos["Correo electrónico"].str.lower().str.strip()

    # Normalizar emails
    df_votos["Correo electrónico"] = df_votos["Correo electrónico"].str.lower().str.strip()
    df_usuarios["email"] = df_usuarios["email"].str.lower().str.strip()

    # === 2️⃣ Validar votantes por correo + código ===
    validos = set(zip(df_usuarios["email"], df_usuarios["codigo"]))
    df_votos["es_valido"] = df_votos.apply(
        lambda r: (r["Correo electrónico"], str(r["Código de participación"])) in validos, axis=1
    )
    df_votos_validos = df_votos[df_votos["es_valido"]]

    if df_votos_validos.empty:
        print("⚠️ No hay votos válidos.")
        return

    # === 3️⃣ Quedarse con la última votación de cada persona ===
    df_votos_validos = (
        df_votos_validos.sort_values("Marca temporal")
        .groupby("Correo electrónico", as_index=False)
        .last()
    )

    # === 4️⃣ Convertir votos a estructura larga (una fila por voto) ===
    lista_votos = []
    for _, row in df_votos_validos.iterrows():
        correo = row["Correo electrónico"]
        votos_persona = [
            (correo, str(row["1º  Fotografía"]).strip(), 3),
            (correo, str(row["2º  Fotografía"]).strip(), 2),
            (correo, str(row["3ª Fotografía"]).strip(), 1),
        ]
        lista_votos.extend(votos_persona)

    df_votos_expandido = pd.DataFrame(lista_votos, columns=["email", "foto", "puntos"])

    # === 5️⃣ Eliminar votos duplicados del mismo usuario a la misma foto ===
    df_votos_filtrado = (
        df_votos_expandido.sort_values("puntos", ascending=False)
        .drop_duplicates(subset=["email", "foto"])
    )

    # === 6️⃣ Agrupar por foto para sumar puntos ===
    ranking = (
        df_votos_filtrado.groupby("foto", as_index=False)["puntos"].sum()
        .rename(columns={"puntos": "num_votos"})
        .sort_values("num_votos", ascending=False)
    )

    # === 7️⃣ Enlazar con el sheet de fotos (por numero_foto) ===
    ranking["foto"] = ranking["foto"].astype(str).str.strip()
    df_fotos["numero_foto"] = df_fotos["numero_foto"].astype(str).str.strip()

    df_resultado = pd.merge(
        ranking,
        df_fotos,
        left_on="foto",
        right_on="numero_foto",
        how="inner"
    )[["id_foto", "numero_foto", "num_votos"]]

    # === 🧮 7.1 Añadir % de votos totales (como texto seguro para Sheets) ===
    total_votos = df_resultado["num_votos"].sum()
    df_resultado["porcentaje_votos"] = df_resultado["num_votos"].apply(
        lambda x: f"{(x / total_votos * 100):.2f}%"
    )


    # === 🧑‍🎨 7.2 Añadir nombre del fotógrafo (por numero_foto) ===
    if "Código de participación" in df_fotografos.columns:
        df_fotografos["Código de participación"] = df_fotografos["Código de participación"].astype(str).str.strip()

    # ==== Normalizar y extraer ID de Drive ====
    def extract_file_id(url):
        """
        Extrae el fileId de Google Drive de enlaces tipo:
        https://drive.google.com/open?id=FILE_ID
        """
        try:
            return url.split("id=")[1]
        except IndexError:
            return None

    df_formulario_fotografo["id_foto_formulario"] = df_formulario_fotografo["Sube tu fotografía"].astype(str).str.strip().apply(extract_file_id)
    df_formulario_fotografo["Correo electrónico"] = df_formulario_fotografo["Correo electrónico"].astype(str).str.strip()
    df_registro["Correo electrónico"] = df_registro["Correo electrónico"].astype(str).str.strip()
    df_registro["Nombre/Nickname"] = df_registro["Nombre/Nickname"].astype(str).str.strip()
    df_registro = df_registro[df_registro["Rol"]=="Fotógrafo"]

    # ==== Filtrar filas del formulario que coincidan con id_foto del ranking ====
    df_fotografos_ranking = df_formulario_fotografo[
        df_formulario_fotografo["id_foto_formulario"].isin(df_resultado["id_foto"])
    ][["id_foto_formulario", "Correo electrónico"]]

    # ==== Merge con registro para obtener el nombre ====
    df_fotografos_ranking = df_fotografos_ranking.merge(
        df_registro[["Correo electrónico", "Nombre/Nickname"]],
        on="Correo electrónico",
        how="left"
    )

    # ==== Crear mapping id_foto -> nombre_fotografo ====
    fotoid_to_nombre = dict(zip(df_fotografos_ranking["id_foto_formulario"], df_fotografos_ranking["Nombre/Nickname"]))

    # ==== Añadir columna al ranking final ====
    df_resultado["nombre_fotografo"] = df_resultado["id_foto"].map(fotoid_to_nombre).fillna("")



    # === 8️⃣ Ordenar y quedarse con el top 3 ===
    df_resultado = df_resultado.sort_values("num_votos", ascending=False).head(3)

    print(df_resultado)

    # === 9️⃣ Guardar en hoja RANKING ===
    sheet_ranking = client.open(SHEET_RANKING).sheet1
    sheet_ranking.clear()
    sheet_ranking.update([df_resultado.columns.values.tolist()] + df_resultado.values.tolist())

    print("🏆 Ranking actualizado correctamente:")
    print(df_resultado)

if __name__ == "__main__":
    main()
