import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
import pandas as pd
import re

# ==== CONFIG ====
SERVICE_ACCOUNT_FILE = "credentials.json"

SHEET_CODIGOS_ID = "UsuariosConCodigo"             # nombre del sheet
SHEET_FOTOGRAFOS_ID = "FormularioFotografo"
SHEET_CONTROL_ID = "ControlNumeroFotografias"
SHEET_LOGIN_ID = "LoginConcursoFotografia"
SHEET_FOTOS_ID = "Fotos"

FOLDER_ORIGINAL_ID = "1qHXNjEA9T6Gw6hggl_jskAmxGuFJxSLaQZ5OWxMCpDfkIaYxD5_YqsENGpN-R4yYl8UPXYQo"
FOLDER_DESTINO_ID = "1t6gbbIhjFkPXkUNjpRAceUuY1ZlZ9ANy"

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]

# ==== FUNCIONES ====

def get_sheets_client():
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return gspread.authorize(creds)

def get_drive_service():
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return build("drive", "v3", credentials=creds)

def fotografos_sheet_to_df(sheet):
    """Convierte el formulario de fotógrafos en DataFrame limpio."""
    data = sheet.get_all_records()
    df = pd.DataFrame(data)
    df_new = pd.DataFrame()
    df_new["email"] = df["Correo electrónico"].astype(str).str.strip().str.lower()
    df_new["codigo"] = df["Código de participación"].astype(str).str.strip()
    df_new["foto_enlace"] = df["Sube tu fotografía"].astype(str).str.strip()
    return df_new

def sheet_to_df(sheet):
    data = sheet.get_all_records()
    return pd.DataFrame(data)

def extract_file_id_from_url(url):
    """Extrae el ID de un enlace de Google Drive."""
    m = re.search(r"/d/([a-zA-Z0-9_-]+)", url)
    if m:
        return m.group(1)
    # A veces los enlaces vienen con ?id=XYZ
    m = re.search(r"id=([a-zA-Z0-9_-]+)", url)
    return m.group(1) if m else None

def move_file(drive_service, file_id, folder_destino_id):
    """Mueve archivo de su carpeta actual a otra."""
    file = drive_service.files().get(fileId=file_id, fields="parents").execute()
    previous_parents = ",".join(file.get("parents", []))
    drive_service.files().update(
        fileId=file_id,
        addParents=folder_destino_id,
        removeParents=previous_parents,
        fields="id, parents"
    ).execute()
    print(f"✅ Archivo {file_id} movido correctamente.")


def move_and_rename_file(drive_service, file_id, folder_destino_id, nuevo_nombre_base):
    """Mueve el archivo a otra carpeta y cambia su nombre."""
    # Obtener carpeta actual
    file = drive_service.files().get(fileId=file_id, fields="name, parents, mimeType").execute()
    nombre_original = file["name"]
    mime_type = file.get("mimeType", "")
    previous_parents = ",".join(file.get("parents", []))
    if folder_destino_id in file.get("parents", []):
        return False

    # Intentar conservar la extensión del nombre original
    extension = ""
    if "." in nombre_original:
        extension = "." + nombre_original.split(".")[-1]
    elif mime_type.startswith("image/"):
        extension = "." + mime_type.split("/")[-1]

    nuevo_nombre = f"{nuevo_nombre_base}{extension}"

    # Actualizar ubicación y nombre
    drive_service.files().update(
        fileId=file_id,
        addParents=folder_destino_id,
        removeParents=previous_parents,
        body={"name": nuevo_nombre},  # 👈 aquí renombramos
        fields="id, name, parents"
    ).execute()

    print(f"✅ Archivo {file_id} movido y renombrado como '{nuevo_nombre}'.")

    return True


# ==== MAIN ====

def main():
    sheets_client = get_sheets_client()
    drive_service = get_drive_service()

    # === LEER SHEETS ===
    df_codigos = sheet_to_df(sheets_client.open(SHEET_CODIGOS_ID).sheet1)
    df_fotos = fotografos_sheet_to_df(sheets_client.open(SHEET_FOTOGRAFOS_ID).sheet1)
    df_control = sheet_to_df(sheets_client.open(SHEET_CONTROL_ID).sheet1)
    df_registro = sheet_to_df(sheets_client.open(SHEET_FOTOS_ID).sheet1)
    df_nombres_fotografos = sheet_to_df(sheets_client.open(SHEET_LOGIN_ID).sheet1)

    # === VALIDAR CODIGOS ===
    df_fotos["codigo_valido"] = df_fotos.apply(
        lambda row: ((row["email"], row["codigo"]) in 
                     set(zip(df_codigos["email"].str.lower(), df_codigos["codigo"]))),
        axis=1
    )
    df_validas = df_fotos[df_fotos["codigo_valido"] == True].copy()

    # === PROCESAR FOTOS ===
    for _, row in df_validas.iterrows():
        email = row["email"].lower()
        file_id = extract_file_id_from_url(row["foto_enlace"])
        if not file_id:
            print(f"❌ No se pudo extraer file_id de {row['foto_enlace']}")
            continue

        # Verificar si el fotógrafo ya subió una foto
        existe_control = df_control[df_control["email_fotografo"].str.lower() == email]
        if not existe_control.empty and existe_control.iloc[0]["fotos_subidas"] >= 3:
            print(f"⚠️ {email} ya ha subido una foto. Se ignora esta subida.")
            continue

        # Calcular número de foto autoincremental
        numero_foto = 0 if df_registro.empty else df_registro["numero_foto"].max() + 1

        # Mover foto
        try:

            email_buscado = email
            rol_buscado = "Fotógrafo"

            print(df_nombres_fotografos)

            nombre_fotografo = df_nombres_fotografos.loc[
                (df_nombres_fotografos["Correo electrónico"].str.lower() == email_buscado.lower()) &
                (df_nombres_fotografos["Rol"].str.lower() == rol_buscado.lower()),
                "Nombre/Nickname"
            ].iloc[0]
            nuevo_nombre = f"{numero_foto}_{nombre_fotografo}"
            archivo_movido = move_and_rename_file(drive_service, file_id, FOLDER_DESTINO_ID,nuevo_nombre)
        except Exception as e:
            print(f"❌ Error al mover archivo {file_id}: {e}")
            continue
        if archivo_movido:
            # Actualizar registro de fotos
            nueva_foto = pd.DataFrame([{"id_foto": file_id, "numero_foto": int(numero_foto)}])
            df_registro = pd.concat([df_registro, nueva_foto], ignore_index=True)

            # Actualizar control del fotógrafo
            if not existe_control.empty:
                idx = df_control.index[df_control["email_fotografo"].str.lower() == email][0]
                df_control.at[idx, "fotos_subidas"] = int(df_control.at[idx, "fotos_subidas"]) + 1
            else:
                nuevo_registro = pd.DataFrame([{"email_fotografo": email, "fotos_subidas": 1}])
                df_control = pd.concat([df_control, nuevo_registro], ignore_index=True)

            print(f"📸 Foto de {email} registrada como número {numero_foto}.")

    # === GUARDAR CAMBIOS EN SHEETS ===
    fotos_sheet = sheets_client.open(SHEET_FOTOS_ID).sheet1
    control_sheet = sheets_client.open(SHEET_CONTROL_ID).sheet1

    fotos_sheet.clear()
    fotos_sheet.update([df_registro.columns.values.tolist()] + df_registro.values.tolist())

    control_sheet.clear()
    control_sheet.update([df_control.columns.values.tolist()] + df_control.values.tolist())

    print("✅ Actualización completa en Sheets y Drive.")

# ==== EJECUTAR ====
if __name__ == "__main__":
    main()
