from flask import Flask, render_template
import gspread
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import os
import io
import shutil

# --- Configuración de Google ---
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/drive.readonly"
]
CREDS = Credentials.from_service_account_file("credentials.json", scopes=SCOPES)
client = gspread.authorize(CREDS)
drive_service = build("drive", "v3", credentials=CREDS)

# ID de tu Google Sheet
SHEET_ID = "1e94pQil1w7bz6kioi_umBQSihiRZSGFK1ICD8Y1IcWE"

# Carpeta local para imágenes
IMAGE_DIR = "static/images"
os.makedirs(IMAGE_DIR, exist_ok=True)

app = Flask(__name__)

def download_image(file_id, filename):
    """Descarga un archivo de Drive a static/images/ si no existe"""
    file_path = os.path.join(IMAGE_DIR, filename)
    if os.path.exists(file_path):
        return file_path
    request = drive_service.files().get_media(fileId=file_id)
    fh = io.FileIO(file_path, "wb")
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while not done:
        status, done = downloader.next_chunk()
    fh.close()
    print(f"Imagen {filename} descargada")
    return file_path

@app.route("/")
def podium():
    sheet = client.open_by_key(SHEET_ID).sheet1
    data = sheet.get_all_records()

    # Ordenar por votos descendente y quedarnos con los top 3
    sorted_data = sorted(data, key=lambda x: x["num_votos"], reverse=True)[:3]

    # Borrar todo el contenido previo de la carpeta
    if os.path.exists(IMAGE_DIR):
        shutil.rmtree(IMAGE_DIR)
    os.makedirs(IMAGE_DIR, exist_ok=True)

    podium_data = []
    for idx, row in enumerate(sorted_data, start=1):
        drive_id = row["id_foto"]
        filename = f"{idx}.jpg"
        download_image(drive_id, filename)

        podium_data.append({
            "image": f"images/{filename}",
            "nombre_fotografo": row.get("nombre_fotografo", ""),
            "porcentaje_votos": row.get("porcentaje_votos", "")
        })

    return render_template("index.html", podium=podium_data)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)
