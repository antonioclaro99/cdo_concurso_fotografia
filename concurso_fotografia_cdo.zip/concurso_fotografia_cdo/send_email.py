import gspread
from google.oauth2.service_account import Credentials
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random
import string
from datetime import datetime

# ==== CONFIGURACIÓN ====

# Archivo de credenciales de cuenta de servicio
SERVICE_ACCOUNT_FILE = "credentials.json"

# Nombres o IDs de las hojas de cálculo
SHEET_A_NAME = "LoginConcursoFotografia"      # Hoja con todos los usuarios
SHEET_B_NAME = "UsuariosConCodigo"   # Hoja con usuarios ya registrados + código

# Configuración del correo
GMAIL_USER = "cdosevillaconcursofotografia@gmail.com"
GMAIL_APP_PASSWORD = "vilgvxckdnpldnwa"  # contraseña de aplicación, no la normal

# ==== FUNCIONES ====

def get_client():
    """Crea un cliente autenticado para Google Sheets."""
    scopes = ["https://www.googleapis.com/auth/spreadsheets",        "https://www.googleapis.com/auth/drive"  # 👈 IMPORTANTE: acceso a Drive
]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=scopes)
    client = gspread.authorize(creds)
    return client

def sheet_to_df(sheet):
    """Convierte una hoja de cálculo en un DataFrame de pandas."""
    data = sheet.get_all_records()
    if not data:
        # Si está vacía, devolvemos estructura esperada
        return pd.DataFrame(columns=["email", "rol", "codigo", "fecha_envio"])
    df = pd.DataFrame(data)
    # Normalizamos los textos
    df["email"] = df["email"].astype(str).str.strip().str.lower()
    df["rol"] = df["rol"].astype(str).str.strip().str.lower()
    # Nos aseguramos de que las columnas existan
    for col in ["codigo", "fecha_envio"]:
        if col not in df.columns:
            df[col] = ""
    return df

def form_sheet_to_df(sheet):
    """Convierte una hoja de cálculo en un DataFrame de pandas."""
    data = sheet.get_all_records()
    if not data:
        # Si está vacía, devolvemos estructura esperada
        return pd.DataFrame(columns=["email", "rol", "codigo", "fecha_envio"])
    df = pd.DataFrame(data)
    df_new = pd.DataFrame()
    # Normalizamos los textos
    df_new["fecha_envio"] = df["Marca temporal"].astype(str).str.strip().str.lower()
    df_new["email"] = df["Correo electrónico"].astype(str).str.strip().str.lower()
    df_new["nombre"] = df["Nombre/Nickname"].astype(str).str.strip().str.lower()
    df_new["rol"] = df["Rol"].astype(str).str.strip().str.lower()
    return df_new

def generate_unique_code(existing_codes, length=6):
    """Genera un código aleatorio único."""
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))
        if code not in existing_codes:
            return code

def send_email(to_email, code, rol):
    """Envía correo con código de verificación."""

    if rol=="Votante":

        subject = f"Tu código de verificación ({rol})"
        body = f"""
Hola {to_email},
Te has registrado en Concurso FotoCosplay CDO como {rol}.

Tu código de verificación como {rol} es: {code}

Puedes acceder al siguiente enlace de drive para ver todas las fotografías que participan hasta el momento: https://drive.google.com/drive/folders/1t6gbbIhjFkPXkUNjpRAceUuY1ZlZ9ANy?usp=drive_link

Para poder votar tus fotografías favoritas, debes utilizar el siguiente formulario: https://forms.gle/rcJgvKNSq3UWvDND8

Recuerda utilizar tu código de participación enviado en este correo. Todas las fotos se nombran como Numero_Fotografo. Para la votación solo debes indicar el número de la foto.

La foto que votes en 1er lugar recibirá 3 puntos, la foto en 2º lugar 2 y la foto en 3er lugar 1. Puedes modificar tu votación a lo largo del día volviendo a votar desde el mismo formulario, solo se tendrá en cuenta la última votación.

No intentes votar la misma foto en los 3 lugares, solo se tomará el mayor lugar como voto válido.

Gracias por participar en Concurso FotoCosplay CDO.

Síguenos en nuestras redes sociales:

Instagram: @cdosevilla 
            """

    else:



        subject = f"Tu código de verificación ({rol})"
        body = f"""
Hola {to_email},
Te has registrado en Concurso FotoCosplay CDO como {rol}.

Tu código de verificación como {rol} es: {code}

Para poder subir tus fotografías, debes utilizar el siguiente formulario: https://forms.gle/rcJgvKNSq3UWvDND8

Recuerda utilizar tu código de participación enviado en este correo. Se recomienda que las fotos estén en formato vertical.

Si deseas participar como votante, debes registrarte nuevamente como votante utilizando el formulario de registro (puedes utilizar el mismo correo si lo deseas).

Gracias por participar en Concurso FotoCosplay CDO.

Síguenos en nuestras redes sociales:

Instagram: @cdosevilla 
"""

    msg = MIMEMultipart()
    msg["From"] = GMAIL_USER
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(GMAIL_USER, GMAIL_APP_PASSWORD)
            server.send_message(msg)
        print(f"✅ Correo enviado a {to_email} ({rol})")
    except Exception as e:
        print(f"❌ Error al enviar correo a {to_email}: {e}")

def main():
    print("🔗 Conectando con Google Sheets...")
    client = get_client()
    print("Conectado")
    sheet_a = client.open(SHEET_A_NAME).sheet1
    print(sheet_a)

    sheet_b = client.open(SHEET_B_NAME).sheet1

    # Leer hojas como DataFrames
    df_a = form_sheet_to_df(sheet_a)
    print(df_a)
    df_b = sheet_to_df(sheet_b)
    print(df_b)


    print(f"📊 Usuarios base: {len(df_a)}  |  Usuarios con código: {len(df_b)}")
    # Comparar por email + rol
    merged = df_a.merge(df_b, on=["email", "rol"], how="left", indicator=True)
    nuevos = merged[merged["_merge"] == "left_only"][["email", "rol"]].copy()

    if nuevos.empty:
        print("✅ No hay nuevos usuarios que procesar.")
        return

    print(f"📋 Detectados {len(nuevos)} nuevos usuarios:")
    print(nuevos)



    # Generar códigos y enviar correos
    existing_codes = set(df_b["codigo"].dropna().astype(str))
    nuevos["codigo"] = [generate_unique_code(existing_codes) for _ in range(len(nuevos))]
    nuevos["fecha_envio"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for _, row in nuevos.iterrows():
        send_email(row["email"], row["codigo"], row["rol"])

    # Actualizar hoja B
    df_actualizado = pd.concat([df_b, nuevos], ignore_index=True)
    print(df_actualizado)
    
    sheet_b.clear()
    sheet_b.update([df_actualizado.columns.values.tolist()] + df_actualizado.values.tolist())
    exit(1)
    print("✅ Sincronización completada y hoja actualizada correctamente.")

if __name__ == "__main__":
    main()
